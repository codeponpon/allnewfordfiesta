this mod allows you to set a fake online time,

so if you set your actual online time to 120 minutes
and fake to 15, then you will get stats of 120 minutes, (boardIndex,infocenter)
but visitors will think its for 15. (boardIndex,infocenter)

this is a very silly mod, 
i hope you enjoy it

Runic
http://www.bryandeakin.com