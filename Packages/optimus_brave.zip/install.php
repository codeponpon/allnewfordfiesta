<?php

if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');
elseif(!defined('SMF'))
	die('<b>Error:</b> Cannot install - please verify that you put this file in the same place as SMF\'s index.php and SSI.php files.');

if ((SMF == 'SSI') && !$user_info['is_admin'])
	die('Admin privileges required.');

// Hooks
$hooks = array(
	'integrate_pre_include' => '$sourcedir/Subs-Optimus.php',
	'integrate_admin_include' => '$sourcedir/Admin-Optimus.php',
	'integrate_load_theme' => 'optimus_home',
	'integrate_admin_areas' => 'optimus_admin_areas',
	'integrate_menu_buttons' => 'optimus_operations',
	'integrate_buffer' => 'optimus_buffer'
);

$call = 'add_integration_function';

foreach ($hooks as $hook => $function)
	$call($hook, $function);
	
db_extend('packages');

$tables[] = array (
	'name' => 'search_terms',
	'columns' => array(
		array(
			'name' => 'id',
			'type' => 'int',
			'size' => 10,
			'auto' => true
		),
		array(
			'name' => 'text',
			'type' => 'varchar',
			'size' => 100,
			'default' => ''
		),
		array(
			'name' => 'hit',
			'type' => 'smallint',
			'size' => 5,
			'null' => false
		),
	),
	'indexes' => array(
		array(
			'type' => 'primary', 
			'columns' => array('id'),
		),
	)
);

foreach($tables as $table)
{
	$smcFunc['db_create_table']('{db_prefix}' . $table['name'], $table['columns'], $table['indexes'], array(), 'update');
	
	if (isset($table['default']))
	{
		$smcFunc['db_insert']('ignore', '{db_prefix}' . $table['name'], $table['default']['columns'], $table['default']['values'], $table['default']['keys']);
	}
}

// Sitemap in Scheduled Tasks
$rows = array();
$rows[] = array(
	'method' => 'ignore',
	'table_name' => '{db_prefix}scheduled_tasks',
	'columns' => array(
		'next_time' => 'int',
		'time_offset' => 'int',
		'time_regularity' => 'int',
		'time_unit' => 'string',
		'disabled' => 'int',
		'task' => 'string',
	),
	'data' => array(0, 0, 1, 'd', 1, 'optimus_sitemap'),
	'keys' => array('id_task'),
);

if (!empty($rows))
	foreach ($rows as $row)
		$smcFunc['db_insert']($row['method'], $row['table_name'], $row['columns'], $row['data'], $row['keys']);

// Some settings
$newSettings = array(
	'optimus_portal_compat' => 0,
	'optimus_forum_index' => $smcFunc['substr']($txt['forum_index'], 7),
	'optimus_description' => $context['forum_name'],
	'optimus_templates' => 'a:0:{}',
	'optimus_meta' => 'a:0:{}',
	'optimus_ignored_actions' => 'admin,bookmarks,credits,helpadmin,pm,printpage'
);

$base = array();
foreach ($newSettings as $setting => $value) {
	if (!isset($modSettings[$setting]))
		$base[$setting] = $value;
}
updateSettings($base);

if (SMF == 'SSI')
	echo 'Database changes are complete! Please wait...';

?>