Board Viewers
by HarzeM
boardviewers@harzem.com

Board Viewers Mod
version: 1.2.1

Ever Wanted to show the number of viewers in the boards on forum index?

Board Viewers mod adds a feature to Board Index to show the number of visitors inside the boards.


-> Adds a text next to each board name, like (21 viewing) or (8 members, 13 guests)
-> Also adds the viewer numbers to child-boards' hover text on boardindex. Like "No new posts (Topics 5, Posts 15,Viewers: 21)"


Features:

-> You can enable or disable this mod in "Admin > Features and Options > Layout and Options"
-> You can seperate guest and member numbers.
-> You can enable a popup on clicking the number. This will list the members inside the board.
-> Any user reading a topic inside a board will also be considered as in the board.
-> Displays the numbers both in board index and in message index with child boards.


DON'T FORGET TO ENABLE THE MOD FROM THE ADMIN PANEL "Admin > Features and Options > Layout and Options"

If you have any problems, questions or comments, please contact me at boardviewers@harzem.com, or preferably ask in the mod forum at www.simplemachines.org


Version Info for SMF 1.1.x:
1.2.1 - Fixed "Undefined index" errors.

1.2 - Added SMF 1.1.x compatibility. Another bug fixed.

1.1 - Added SMF 1.1 compatibility. A single bug fixed.

1.0 - Added RC3 compatibility, removed SMF 1.0.x compatibility.
    - Added several new features. Probably the last release except from bug fixes.

0.6 - Fixed a bug that causes the error log to fill up.

0.5 - First Release