<?php
/*  Copyright 2005-2012 Michael Oestergaard Pedersen

    This file is part of Users Online Today Mod.

    Users Online Today Mod is free software: you can redistribute it and/or
    modify it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the License,
    or (at your option) any later version.

    Users Online Today Mod is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License along
    with Users Online Today Mod.  If not, see <http://www.gnu.org/licenses/>.
*/

if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');
elseif (!defined('SMF'))
	die('<b>Error:</b> Cannot uninstall - please verify you put this in the same place as SMF\'s index.php.');

// Remove the integration hooks for this mod
remove_integration_function('integrate_pre_include', '$sourcedir/Subs-UsersOnlineToday.php');
remove_integration_function('integrate_general_mod_settings','UsersOnlineToday_settings');

if (SMF == 'SSI')
	echo 'Uninstallation successful!';

?>
