Thank you for using the Users Online Today Modification.

This modification allows users to see who logged in during the day.

Options: Administration Center > Modification Settings > Miscellaneous
