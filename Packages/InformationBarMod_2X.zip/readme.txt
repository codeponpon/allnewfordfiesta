[center][img]http://bit.ly/kZVDB6[/img][/center]

[center][glow=black,2,300][color=purple][size=16pt][b]InformationBar 1.0[/b][/size][/color][/glow]
[b]Developed by[/b] [b][url=http://www.smfsimple.com/index.php?action=profile;u=55]4kstore[/url][/b] [b]for [/b][b][url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[i][b]SMF 1.1.X, 2.0 RCX, 2.0.X[/b][/i][/center]

[hr]

[center][glow=black,2,300][color=orange][size=14pt][b]El soporte oficial de los desarrolladores de nuestros mods lo encontraras en SMFSimple.com[/b][/size][/color][/glow][/center]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]It allows to create one pretty bar of information in the forum in which can be put important messages.
The bar can be activated from the administration panel[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripcion:[/b][/u][/size][/color][/glow]
[i][b]Permite crear una linda barra de informaci�n en el foro en la cual se pueden poner mensajes importantes.
La barra se puede activar desde el panel de administracion[/b][/i]

[center][glow=black,2,300][color=red][size=13pt][b]Screenshots | Imagenes[/b][/size][/color][/glow][/center]

[center]
[IMG]http://i.imgur.com/3tCM8.png[/IMG]

[IMG]http://i.imgur.com/bJvEk.png[/IMG]
[/center]

[hr]
[color=teal][u][b]Language Support | Lenguajes Soportados[/b][/u][/color]
[color=teal][b]
o English
o Spanish_latin	
[/b][/color]
[hr]

[center][glow=black,2,300][color=green][size=15pt][b]InformationBar[/b][/size][/color][/glow][/center]
